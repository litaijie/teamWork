/**
 * Copyright (c) 2016-2019 人人开源 All rights reserved.
 *
 * https://www.renren.io
 *
 * 版权所有，侵权必究！
 */

package io.renren.modules.business.dao;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import io.renren.commons.dynamic.datasource.annotation.DataSource;
import io.renren.modules.business.DTO.QueryParam;
import io.renren.modules.business.entity.HVConsumables;
import io.renren.modules.business.entity.outpatientDepartment.Drug;
import io.renren.modules.business.entity.outpatientDepartment.Examine;
import io.renren.modules.business.entity.outpatientDepartment.Fever;
import io.renren.modules.business.entity.outpatientDepartment.Lab;
import io.renren.modules.sys.entity.SysDeptEntity;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.Map;

/**
 * 报表查询
 *
 * @author Mark sunlightcs@gmail.com
 */
@Mapper
@DataSource("slave1")
public interface ReportsMapper extends BaseMapper<SysDeptEntity> {
    /**
     *1高值耗材
     */
    String hVConsumables = "with s as\n" +
            "(select a.shoufeiyonghuming,a.zhuyuankeshi,sum(a.shishoufeiyong) jine,sum(a.shuliang) shuliang from z_feiyong${param.year}  a where to_char(jiesuanshijian,'yyyy-MM')='${param.yearMonth}' and caiwuid in ('24','34') and danjia>=500 group by a.shoufeiyonghuming,a.zhuyuankeshi),\n" +
            "t as\n" +
            "(select a.jisuanjibianma,a.zhuyuankeshi,a.danwei,sum(a.shishoufeiyong) jine,sum(a.shuliang) shuliang from z_feiyong${param.year}  a where to_char(jiesuanshijian,'yyyy-MM')='${param.yearMonth}' and caiwuid in ('24','34') and danjia>=500 group by a.jisuanjibianma,a.zhuyuankeshi,a.danwei)\n" +
            "select keshi.keshimingcheng,jine.jine,keshi.names,yisheng.names from \n" +
            "(select a.zhuyuankeshi,sum(a.shishoufeiyong) jine from z_feiyong${param.year}  a where to_char(jiesuanshijian,'yyyy-MM')='${param.yearMonth}' and caiwuid in ('24','34') and danjia>=500 group by a.zhuyuankeshi) jine,\n" +
            "(SELECT hc.keshiid,hc.keshimingcheng,listagg (hc.name, ',') WITHIN GROUP (ORDER BY hc.shuliang desc) names from (\n" +
            "select ks.keshiid,ks.keshimingcheng,x.mingcheng||' '||fy.shuliang||fy.danwei name,fy.shuliang from (\n" +
            "select  t.*,row_number() over(partition by t.zhuyuankeshi order by t.shuliang desc) pm from t) fy,x_keshi ks,x_feiyongbiaozhun x where fy.jisuanjibianma=x.jisuanjibianma and fy.zhuyuankeshi=ks.keshiid and fy.pm<=3) hc group by hc.keshiid,hc.keshimingcheng) keshi,\n" +
            "(SELECT hc.zhuyuankeshi,listagg (hc.name, ',') WITHIN GROUP (ORDER BY hc.jine desc) names from (select fy.zhuyuankeshi,fy.shoufeiyonghuming||' '||fy.jine name,fy.jine from (\n" +
            "select  s.*,row_number() over(partition by s.zhuyuankeshi order by s.jine desc) pm from s) fy where  fy.pm<=3) hc group by hc.zhuyuankeshi) yisheng \n" +
            "where jine.zhuyuankeshi=keshi.keshiid and jine.zhuyuankeshi=yisheng.zhuyuankeshi";
    @Select(hVConsumables)
    List<HVConsumables> hVConsumables(@Param("param")QueryParam param);

    /**
     * 2药品
     */
    String drugs = "with s as\n" +
            "(select a.shoufeiyonghuming,a.shoufeikeshiid,a.danwei,sum(a.shishoufeiyong) jine,sum(a.shuliang) shuliang from z_feiyong${param.year}  a where to_char(jiesuanshijian,'yyyy-MM')='${param.yearMonth}' and caiwuid in ('17','18','19') and a.danjia>=50 group by a.shoufeiyonghuming,a.shoufeikeshiid,a.danwei),\n" +
            "t as\n" +
            "(select a.jisuanjibianma,a.shoufeikeshiid,a.danwei,sum(a.shishoufeiyong) jine,sum(a.shuliang) shuliang from z_feiyong${param.year}  a where to_char(jiesuanshijian,'yyyy-MM')='${param.yearMonth}' and caiwuid in ('17','18','19') and a.danjia>=50  group by a.jisuanjibianma,a.shoufeikeshiid,a.danwei)\n" +
            "\n" +
            "select keshi.keshimingcheng,jine.jine,keshi.names,yisheng.names from\n" +
            "(select a.shoufeikeshiid,sum(a.shishoufeiyong) jine from z_feiyong${param.year}  a where to_char(jiesuanshijian,'yyyy-MM')='${param.yearMonth}' and caiwuid in ('17','18','19')  and danjia>=50 group by a.shoufeikeshiid) jine,\n" +
            "(SELECT hc.keshiid,hc.keshimingcheng,listagg (hc.name, ',') WITHIN GROUP (ORDER BY hc.shuliang desc) names from (\n" +
            "select ks.keshiid,ks.keshimingcheng,x.mingcheng||' '||fy.shuliang||fy.danwei name,fy.shuliang from (\n" +
            "select  t.*,row_number() over(partition by t.shoufeikeshiid order by t.shuliang desc) pm from t) fy,x_keshi ks,x_yaopin x where fy.jisuanjibianma=x.yaopinid and fy.shoufeikeshiid=ks.keshiid and fy.pm<=5) hc group by hc.keshiid,hc.keshimingcheng) keshi,\n" +
            "(SELECT hc.shoufeikeshiid,listagg (hc.name, ',') WITHIN GROUP (ORDER BY hc.jine desc) names from (select fy.shoufeikeshiid,fy.shoufeiyonghuming||' '||fy.jine name,fy.jine from (\n" +
            "select  s.*,row_number() over(partition by s.shoufeikeshiid order by s.jine desc) pm from s) fy where  fy.pm<=3) hc group by hc.shoufeikeshiid) yisheng\n" +
            "where jine.shoufeikeshiid=keshi.keshiid and jine.shoufeikeshiid=yisheng.shoufeikeshiid";
    @Select(hVConsumables)
    List<HVConsumables> drugs(@Param("param")QueryParam param);

    /**
     * 3各科室耗材使用情况表
     */
    String hVConsumablesByDept = "select keshimingcheng 科室,sum(hcje) 耗材金额,sum(pthc) 普通耗材金额,sum(gzhc) 高值金额,sum(zje) 总金额,round(sum(hcje)/sum(zje),4)*100 耗材占比 from (\n" +
            "select a.zhuyuankeshi,0 hcje,0 pthc,sum(a.shishoufeiyong) gzhc,0 zje from z_feiyong${param.year} a where to_char(jiesuanshijian,'yyyy-MM')='${param.yearMonth}'and caiwuid in ('24','34') and danjia>=500 group by a.zhuyuankeshi \n" +
            "union all\n" +
            "select a.zhuyuankeshi,0 hcje,sum(a.shishoufeiyong) pthc,0 gzhc,0 zje from z_feiyong${param.year} a where to_char(jiesuanshijian,'yyyy-MM')='${param.yearMonth}'and caiwuid in ('24','34') and danjia<500 group by a.zhuyuankeshi\n" +
            "union all\n" +
            "select a.zhuyuankeshi,sum(a.shishoufeiyong) hcje,0 pthc,0 gzhc,0 zje from z_feiyong${param.year} a where to_char(jiesuanshijian,'yyyy-MM')='${param.yearMonth}'and caiwuid in ('24','34') group by a.zhuyuankeshi\n" +
            "union all select a.zhuyuankeshi,0 hcje,0 pthc,0 gzhc,sum(a.shishoufeiyong) zje from z_feiyong${param.year} a where to_char(jiesuanshijian,'yyyy-MM')='${param.yearMonth}' group by a.zhuyuankeshi) a,x_keshi b where a.zhuyuankeshi=b.keshiid  group by keshimingcheng";
    @Select(hVConsumablesByDept)
    List<HVConsumables> hVConsumablesByDept(@Param("param")QueryParam param);

    /**
     * 4各科室药品使用情况
     */
    String drugsByDept = "select keshimingcheng 科室,sum(hcje) 药品金额,sum(pthc) 普通药品金额,sum(gzhc) 贵重药品金额,sum(zje) 总金额,round(sum(hcje)/sum(zje),4)*100 药占比 from (\n" +
            "select a.shoufeikeshiid,0 hcje,0 pthc,sum(a.shishoufeiyong) gzhc,0 zje from z_feiyong${param.year} a where to_char(jiesuanshijian,'yyyy-MM')='${param.yearMonth}'and caiwuid in ('17','18','19') and danjia>=50 group by a.shoufeikeshiid\n" +
            "union all\n" +
            "select a.shoufeikeshiid,0 hcje,sum(a.shishoufeiyong) pthc,0 gzhc,0 zje from z_feiyong${param.year} a where to_char(jiesuanshijian,'yyyy-MM')='${param.yearMonth}'and caiwuid in ('17','18','19') and danjia<50 group by a.shoufeikeshiid\n" +
            "union all\n" +
            "select a.shoufeikeshiid,sum(a.shishoufeiyong) hcje,0 pthc,0 gzhc,0 zje from z_feiyong${param.year} a where to_char(jiesuanshijian,'yyyy-MM')='${param.yearMonth}'and caiwuid in ('17','18','19') group by a.shoufeikeshiid\n" +
            "union all select a.shoufeikeshiid,0 hcje,0 pthc,0 gzhc,sum(a.shishoufeiyong) zje from z_feiyong${param.year} a where to_char(jiesuanshijian,'yyyy-MM')='${param.yearMonth}' group by a.shoufeikeshiid) a,x_keshi b where a.shoufeikeshiid=b.keshiid   group by keshimingcheng having sum(hcje)!=0";
    @Select(drugsByDept)
    List<HVConsumables> drugsByDept(@Param("param")QueryParam param);

    /**
     * 5使用量前10高值耗材
     */
    String hVConsumables10 = "select c.mingcheng 名称,c.guige 规格,a.danjia 单价,a.jine 总金额,a.shuliang 数量,b.names 前三 from (\n" +
            "select jisuanjibianma,danjia,sum(shishoufeiyong) jine,sum(shuliang) shuliang,ROW_NUMBER() over(order by sum(shishoufeiyong) desc) rn from z_feiyong${param.year} where to_char(jiesuanshijian,'yyyy-MM')='${param.yearMonth}'and caiwuid in ('24','34') and danjia>=500 group by jisuanjibianma,danjia ) a,(\n" +
            "select jisuanjibianma,listagg (name, ',') WITHIN GROUP (ORDER BY rn) names from (\n" +
            "select jisuanjibianma,shoufeiyonghuming||' '||shuliang||danwei name,rn from (\n" +
            "select jisuanjibianma,shoufeiyonghuming,danwei,sum(shuliang) shuliang,ROW_NUMBER() over(partition by jisuanjibianma order by sum(shishoufeiyong) desc) rn from z_feiyong${param.year} where to_char(jiesuanshijian,'yyyy-MM')='${param.yearMonth}'and caiwuid in ('24','34') and danjia>=500 group by jisuanjibianma,shoufeiyonghuming,danwei) where rn<=3) group by jisuanjibianma) b，x_feiyongbiaozhun c where a.jisuanjibianma=b.jisuanjibianma and a.jisuanjibianma=c.jisuanjibianma and a.rn<=10";
    @Select(hVConsumables10)
    List<HVConsumables> hVConsumables10(@Param("param")QueryParam param);

    /**
     * 6使用量前10药品
     */
    String drugs10 = "select c.mingcheng 名称,c.guigemingcheng 规格,a.danjia 单价,a.jine 总金额,a.shuliang 数量,b.names 前三 from (\n" +
            "select jisuanjibianma,danjia,sum(shishoufeiyong) jine,sum(shuliang) shuliang,ROW_NUMBER() over(order by sum(shishoufeiyong) desc) rn from z_feiyong${param.year} where to_char(jiesuanshijian,'yyyy-MM')='${param.yearMonth}'and caiwuid in ('17','18','19') group by jisuanjibianma,danjia ) a,(\n" +
            "select jisuanjibianma,listagg (name, ',') WITHIN GROUP (ORDER BY rn) names from (\n" +
            "select jisuanjibianma,shoufeiyonghuming||' '||shuliang||danwei name,rn from (\n" +
            "select jisuanjibianma,shoufeiyonghuming,danwei,sum(shuliang) shuliang,ROW_NUMBER() over(partition by jisuanjibianma order by sum(shishoufeiyong) desc) rn from z_feiyong${param.year} where to_char(jiesuanshijian,'yyyy-MM')='${param.yearMonth}'and caiwuid in ('17','18','19') group by jisuanjibianma,shoufeiyonghuming,danwei) where rn<=3) group by jisuanjibianma) b，x_yaopin c where a.jisuanjibianma=b.jisuanjibianma and a.jisuanjibianma=c.yaopinid and a.rn<=12";
    @Select(drugs10)
    List<HVConsumables> drugs10(@Param("param")QueryParam param);

    /**
     * drug_诊疗处方记录表
     */
    String mDrug = "with z_dangan_lgsb as\n" +
            " (select m_danganid M_DANGANID, m_rizhiid m_RIZHIID, '0' AA, sysdate SHIJIAN\n" +
            "    from m_lczhenduan${param.year}\n" +
            "   where 1 = 1\n" +
            "     and to_date(rizhiid, 'yyyymmdd') >=\n" +
            "         to_date('${param.startDate} 00:00:00', 'yyyy-mm-dd hh24:mi:ss')\n" +
            "     and to_date(rizhiid, 'yyyymmdd') <=\n" +
            "         to_date('${param.endDate} 23:59:59', 'yyyy-mm-dd hh24:mi:ss')\n" +
            "     and icd10id in (select icd10id from x_icd10 where icd10 like 'J__.%')\n" +
            "   group by m_danganid, m_rizhiid)\n" +
            "select nvl(a.kahao,'000000') P7502,\n" +
            "       nvl(to_char(rz.shijian, 'yyyy-mm-dd hh24:mi:ss'),'-') P7506,\n" +
            "       nvl(rz.m_rizhiid,'-') P7000,\n" +
            "       nvl(a.xingming,'-') P4,\n" +
            "       nvl(b.chufangid,'-') P7800,\n" +
            "       nvl(to_char(b.xiadashijian, 'yyyy-mm-dd hh24:mi:ss'),'-') P7801,\n" +
            "       '-' P7802,\n" +
            "       decode(yp.fenleiid, '20', '11', '00', '12', '10', '13', '50', '13') P7803,\n" +
            "       decode(yp.fenleiid, '20', '1', '00', '2', '10', '3', '50', '9') P7804,\n" +
            "       yp.yaopinid P7805,\n" +
            "       nvl(yp.mingcheng,'-') P7806,\n" +
            "       '-' P7807,\n" +
            "       '-' P7808,\n" +
            "       '-' P7810,\n" +
            "       '-' P7811,\n" +
            "       '-' P7812,\n" +
            "       '-' P7813,\n" +
            "       nvl(yp.guigemingcheng,'-') P7814,\n" +
            "       nvl(pc.suoxie,'-') P7815,\n" +
            "       c.fuyongliang P7816,\n" +
            "       c.fuyongjiliang P7817,\n" +
            "       nvl(c.danwei,'-') P7818,\n" +
            "       '-' P7819,\n" +
            "       '-' P7820,\n" +
            "       decode(c.pishijieguo, '0', '2', '2', '1', '9', '2'，'-') P7821,\n" +
            "       '-' P7822,\n" +
            "       '-' P7823,\n" +
            "       c.tianshu P7824,\n" +
            "       '-' P7825,\n" +
            "       '-' P7826,\n" +
            "       '-' P7827,\n" +
            "       '-' P7828,\n" +
            "       '-' P7829,\n" +
            "       '-' P7830,\n" +
            "       '-' P7831,\n" +
            "       '-' P7832\n" +
            "  from m_dangan       a,\n" +
            "       m_yizhu${param.year}    b,\n" +
            "       m_yizhu_mx${param.year} c,\n" +
            "       x_yaopin       yp,\n" +
            "       m_rizhi${param.year}    rz,\n" +
            "       x_yzpinchi     pc,\n" +
            "       z_dangan_lgsb  lg\n" +
            " where a.m_danganid = b.m_danganid\n" +
            "   and b.chufangid = c.chufangid\n" +
            "   and c.yaopinid = yp.yaopinid\n" +
            "   and b.m_rizhiid = rz.m_rizhiid\n" +
            "   and c.pinchi = pc.pinchiid\n" +
            "   and rz.m_rizhiid = lg.m_rizhiid;";
    @Select(mDrug)
    List<Drug> mDrug(@Param("param")QueryParam param);

    /**
     * examine_辅助检查记录表
     */
    String mExamine = "with z_dangan_lgsb as\n" +
            " (select m_danganid M_DANGANID, m_rizhiid m_RIZHIID, '0' AA, sysdate SHIJIAN\n" +
            "    from m_lczhenduan${param.year}\n" +
            "   where 1 = 1\n" +
            "     and to_date(rizhiid, 'yyyymmdd') >=\n" +
            "         to_date('${param.startDate} 00:00:00', 'yyyy-mm-dd hh24:mi:ss')\n" +
            "     and to_date(rizhiid, 'yyyymmdd') <=\n" +
            "         to_date('${param.endDate} 23:59:59', 'yyyy-mm-dd hh24:mi:ss')\n" +
            "     and icd10id in (select icd10id from x_icd10 where icd10 like 'J__.%')\n" +
            "   group by m_danganid, m_rizhiid)\n" +
            "select nvl(da.kahao,'000000') P7502,\n" +
            "       nvl(to_char(rz.shijian, 'yyyy-mm-dd hh24:mi:ss'),'-')  P7506,\n" +
            "       nvl(rz.m_rizhiid,'-') P7000,\n" +
            "       nvl(da.xingming,'-') P4,\n" +
            "       '-' P7701,\n" +
            "       '-' P7702,\n" +
            "       '-' P7703,\n" +
            "       nvl(rz.rizhiid || fj.binglihao || fj.xiangmuid,'-') P7704,\n" +
            "       '-' P7705,\n" +
            "       nvl(to_char(fj.jianchashijian, 'yyyy-mm-dd hh24:mi:ss'),'-') P7706,\n" +
            "       '-' P7707,\n" +
            "       '-' P7708,\n" +
            "       '-' P7709,\n" +
            "       '-' P7710,\n" +
            "       nvl(xm.xiangmuid,'-') P7711,\n" +
            "       nvl(xm.mingcheng,'-') P7712,\n" +
            "       nvl(fl.fenleiming,'-') P7713,\n" +
            "       decode(fj.yinyangxing, '阳性', '1', '2') P7714,\n" +
            "       nvl(substr(fj.baogaoxiaojie, 1, instr(baogaoxiaojie, '检查结论') - 1),'-') P7715,\n" +
            "       '-' P7716,\n" +
            "       nvl(substr(fj.baogaoxiaojie, instr(baogaoxiaojie, '检查结论')),'-') P7717\n" +
            "  from m_lcfujian${param.year}  fj,\n" +
            "       x_fujianxiangmu xm,\n" +
            "       x_fujianfenlei  fl,\n" +
            "       m_dangan        da,\n" +
            "       m_rizhi${param.year}     rz,\n" +
            "       z_dangan_lgsb   lgsb\n" +
            " where fj.xiangmuid = xm.xiangmuid\n" +
            "   and fj.fenleiid = fl.fenleiid\n" +
            "   and fj.danganid = da.m_danganid\n" +
            "   and fj.m_rizhiid = rz.m_rizhiid\n" +
            "   and fj.m_rizhiid = lgsb.m_rizhiid\n" +
            "   and jianchakeshiid = 'JC03';\n";
    @Select(mExamine)
    List<Examine> mExamine(@Param("param")QueryParam param);

    /**
     * fever_发热门诊病例信息
     */
    String mFever = "with z_dangan_lgsb as(\n" +
            "select m_danganid M_DANGANID, rizhiid M_RIZHIID, '0' AA, sysdate SHIJIAN\n" +
            "from m_lczhenduan${param.year} \n" +
            "where 1 = 1\n" +
            "and to_date(rizhiid,'yyyymmdd') >= to_date('${param.startDate} 00:00:00','yyyy-mm-dd hh24:mi:ss') \n" +
            "and to_date(rizhiid,'yyyymmdd') <= to_date('${param.endDate} 23:59:59','yyyy-mm-dd hh24:mi:ss') \n" +
            "and icd10id in (select icd10id from x_icd10 where icd10 like 'J__.%') \n" +
            "group by m_danganid, rizhiid)\n" +
            "--SELECT * FROM z_dangan_lgsb\n" +
            "select \n" +
            "'499373155' P900,--医疗机构代码\n" +
            "'贵港市中西医结合骨科医院' P6891,--机构名称\n" +
            "nvl(da.baoxianhao,'-') P686,--医疗保险卡号\n" +
            "'-' P800,--健康卡号\n" +
            "nvl(decode(gh.jizhenbiaoji, '1', '02', '01'), '-') P7501,--就诊类型 01-门诊 02-急诊 03-住院\n" +
            "nvl(da.kahao,'000000') P7502,--就诊卡号 \n" +
            "nvl(lgsb.m_rizhiid, '-') P7000,\n" +
            "nvl(da.xingming, '-') P4,--姓名\n" +
            "nvl(decode(da.xingbie, '1', '1', '2', '2', '9'), '-') P5,--性别 0-未知的性别;1-男 2-女 9-未说明\n" +
            "nvl(to_char(to_date(da.chushengriqi, 'yyyymmdd'), 'yyyy-mm-dd') || ' ' || da.chushengshijian, '-') P6,\n" +
            "trunc((trunc(gh.guahaoshijian, 'dd') - trunc(to_date(da.chushengriqi, 'yyyymmdd'), 'dd')) / 365) P7,\n" +
            "'-' P12,'-'P11,'-'P8,'-'P9,\n" +
            "'01' P7503,--注册证件类型代码 \n" +
            "nvl(da.shenfenzhenghao, '-') P13,--注册证件号码\n" +
            "--nvl(gh.keshiid,'-') P7504,--就诊科室代码\n" +
            "nvl(da.jiatingdizhi,'-') P801,\n" +
            "nvl(da.lianxidianhua,'-') P802,\n" +
            "nvl(da.youbian,'-') P803,\n" +
            "'-' P14,'-'P15,'-'P16,nvl(DA.LIANXIREN,'-') P17,'-' P19,'-' P20,'-' P21,\n" +
            "'-' P7505,--就诊次数\n" +
            "'-' P7520,'-' P7521,\n" +
            "'-' P7504,--就诊科室代码\n" +
            "'-' P7522,\n" +
            "nvl(to_char(gh.guahaoshijian, 'yyyy-mm-dd hh24:mi:ss'),'-') P7506,--就诊日期\n" +
            "'-' P7507,--主诉\n" +
            "'-' P7523,'-' P7524,'-' P7525,\n" +
            "nvl(zd.jibingming,'-') P7526,\n" +
            "'-' P7527,'-' P7528, '-'P7529,\n" +
            "nvl(zd.icd10,'-') P28,--主要疾病诊断代码\n" +
            "nvl(zd.jibingming,'-') P281,--主要疾病诊断描述\n" +
            "'-'P7530,\n" +
            "\n" +
            "'-' P1,--数字 医疗费用支付方式代码\n" +
            "(case when fy.shishoufeiyong is null or fy.shishoufeiyong<0 then 0 else fy.shishoufeiyong end) P7508,--总费用\n" +
            "(case when ghfy.shishoufeiyong is null or ghfy.shishoufeiyong<0 then 0 else ghfy.shishoufeiyong end) P7509,--挂号费\n" +
            "(case when ypfy.shishoufeiyong is null or ypfy.shishoufeiyong<0 then 0 else ypfy.shishoufeiyong end) P7510,--药品费\n" +
            "(case when jcfy.shishoufeiyong is null or jcfy.shishoufeiyong<0 then 0 else jcfy.shishoufeiyong end) P7511,--检查费\n" +
            "(case when (fy.shishoufeiyong-ybsj.yyfd) is null or (fy.shishoufeiyong-ybsj.yyfd) <0 then 0 else (fy.shishoufeiyong-ybsj.yyfd) end) P7512 --自付费用\n" +
            "\n" +
            "from z_dangan_lgsb lgsb\n" +
            "inner join m_dangan da on lgsb.m_danganid = da.m_danganid\n" +
            "inner join \n" +
            "(\n" +
            "select m_danganid, rizhiid, keshiid, guahaoshijian, jizhenbiaoji, row_number() over(partition by m_danganid, rizhiid order by \n" +
            "\n" +
            "guahaoshijian) rn from m_guahao${param.year} \n" +
            ") gh on lgsb.m_danganid = gh.m_danganid and lgsb.m_rizhiid = gh.rizhiid and gh.rn = 1\n" +
            "left join \n" +
            "(\n" +
            "select inzd.m_danganid, inzd.rizhiid, inzd.icd10id, inicd.icd10, inicd.jibingming, row_number() over(partition by inzd.m_danganid, \n" +
            "\n" +
            "inzd.rizhiid order by inzd.zhuzhenduan, inzd.shijian) rn from m_lczhenduan${param.year} inzd, x_icd10 inicd where inzd.icd10id = inicd.icd10id \n" +
            "\n" +
            "and inzd.zhuzhenduan = '0'\n" +
            ") zd on gh.m_danganid = zd.m_danganid and gh.rizhiid = zd.rizhiid and zd.rn = 1\n" +
            "\n" +
            "left join \n" +
            "(\n" +
            "  select m_danganid, rizhiid, sum(shishoufeiyong) shishoufeiyong\n" +
            "  from \n" +
            "  (\n" +
            "    select m_danganid, rizhiid, sum(shishoufeiyong) shishoufeiyong from m_feiyong where jiucuobiaoji='0'group by m_danganid, rizhiid\n" +
            "    union all \n" +
            "    select m_danganid, rizhiid, sum(shishoufeiyong) shishoufeiyong from m_feiyong${param.year} where jiucuobiaoji='0'and chongxiaobiaoji='0' \n" +
            "\n" +
            "group by m_danganid, rizhiid\n" +
            "  )\n" +
            "  group by m_danganid, rizhiid \n" +
            ") fy on gh.m_danganid = fy.m_danganid and gh.rizhiid = fy.rizhiid\n" +
            "left join \n" +
            "(\n" +
            "  select m_danganid, rizhiid, sum(shishoufeiyong) shishoufeiyong\n" +
            "  from \n" +
            "  (\n" +
            "    select m_danganid, rizhiid, sum(shishoufeiyong) shishoufeiyong from m_feiyong where shoujuid = '00'and jiucuobiaoji='0' group by \n" +
            "\n" +
            "m_danganid, rizhiid\n" +
            "    union all \n" +
            "    select m_danganid, rizhiid, sum(shishoufeiyong) shishoufeiyong from m_feiyong${param.year} where shoujuid = '00' and jiucuobiaoji='0'and \n" +
            "\n" +
            "chongxiaobiaoji='0'group by m_danganid, rizhiid\n" +
            "  )\n" +
            "  group by m_danganid, rizhiid \n" +
            ") ghfy on gh.m_danganid = ghfy.m_danganid and gh.rizhiid = ghfy.rizhiid\n" +
            "left join \n" +
            "(\n" +
            "  select m_danganid, rizhiid, sum(shishoufeiyong) shishoufeiyong\n" +
            "  from \n" +
            "  (\n" +
            "    select m_danganid, rizhiid, sum(shishoufeiyong) shishoufeiyong from m_feiyong where shoujuid in('01','02','03') and \n" +
            "\n" +
            "jiucuobiaoji='0'group by m_danganid, rizhiid having sum(shishoufeiyong)>=0\n" +
            "    union all \n" +
            "    select m_danganid, rizhiid, sum(shishoufeiyong) shishoufeiyong from m_feiyong${param.year} where shoujuid in('01','02','03') and \n" +
            "\n" +
            "jiucuobiaoji='0'and chongxiaobiaoji='0' group by m_danganid, rizhiid having sum(shishoufeiyong)>=0\n" +
            "  )\n" +
            "  group by m_danganid, rizhiid \n" +
            ") ypfy on gh.m_danganid = ypfy.m_danganid and gh.rizhiid = ypfy.rizhiid\n" +
            "left join \n" +
            "(\n" +
            "  select m_danganid, rizhiid, sum(shishoufeiyong) shishoufeiyong\n" +
            "  from \n" +
            "  (\n" +
            "    select m_danganid, rizhiid, sum(shishoufeiyong) shishoufeiyong from m_feiyong where shoujuid = '06'and jiucuobiaoji='0' group by \n" +
            "\n" +
            "m_danganid, rizhiid\n" +
            "    union all \n" +
            "    select m_danganid, rizhiid, sum(shishoufeiyong) shishoufeiyong from m_feiyong${param.year} where shoujuid = '06'and jiucuobiaoji='0'and \n" +
            "\n" +
            "chongxiaobiaoji='0' group by m_danganid, rizhiid\n" +
            "  )\n" +
            "  group by m_danganid, rizhiid having sum(shishoufeiyong)>=0\n" +
            ") jcfy on gh.m_danganid = jcfy.m_danganid and gh.rizhiid = jcfy.rizhiid\n" +
            "left join \n" +
            "(\n" +
            "  select m_danganid, shoufeiriqi rizhiid, sum(JiJinZhiFu + ZhangHuZhiFu) yyfd from m_ybshouju${param.year} where jiesuan='1'group by \n" +
            "\n" +
            "m_danganid, shoufeiriqi having sum(JiJinZhiFu + ZhangHuZhiFu)>=0\n" +
            ") ybsj on gh.m_danganid = ybsj.m_danganid and gh.rizhiid = ybsj.rizhiid\n" +
            "where 1 = 1;";
    @Select(mFever)
    List<Fever> mFever(@Param("param")QueryParam param);

    /**
     * fever_发热门诊病例信息
     */
    String mLab = "with z_dangan_lgsb as\n" +
            " (select m_danganid M_DANGANID, m_rizhiid m_RIZHIID, '0' AA, sysdate SHIJIAN\n" +
            "    from m_lczhenduan${param.year}\n" +
            "   where 1 = 1\n" +
            "     and to_date(rizhiid, 'yyyymmdd') >=\n" +
            "         to_date('${param.startDate} 00:00:00', 'yyyy-mm-dd hh24:mi:ss')\n" +
            "     and to_date(rizhiid, 'yyyymmdd') <=\n" +
            "         to_date('${param.endDate} 23:59:59', 'yyyy-mm-dd hh24:mi:ss')\n" +
            "     and icd10id in (select icd10id from x_icd10 where icd10 like 'J__.%')\n" +
            "   group by m_danganid, m_rizhiid)\n" +
            "select nvl(da.kahao,'000000') P7502,\n" +
            "       nvl(to_char(a.songjianshijian, 'yyyy-mm-dd hh24:mi:ss'),'-') P7506,\n" +
            "       nvl(a.m_rizhiid,'-') P7000,\n" +
            "       nvl(a.xingming,'-') P4,\n" +
            "       '-' P7601,\n" +
            "       '-' P7602,\n" +
            "       '一般临床检验' P7603,\n" +
            "       '1' P7604,\n" +
            "       nvl(c.tiaoxingma,'-') P7605,\n" +
            "       '-' P7606,\n" +
            "       nvl(to_char(d.jianyandate, 'yyyy-mm-dd hh24:mi:ss'),'-') P7607,\n" +
            "       nvl(to_char(d.biaogaodate, 'yyyy-mm-dd hh24:mi:ss'),'-') P7608,\n" +
            "       nvl(to_char(d.sjdate, 'yyyy-mm-dd hh24:mi:ss'),'-') P7609,\n" +
            "       nvl(to_char(d.qsdate, 'yyyy-mm-dd hh24:mi:ss'),'-') P7610,\n" +
            "       nvl(d.biaobenhao,0) P7611,   --\n" +
            "       nvl(bb.bbmingcheng,'-') P7612,\n" +
            "       nvl(a.xiangmuid,'-') P7613,\n" +
            "       nvl(x.mingcheng,'-') P7614,\n" +
            "       nvl(e.xiangmuid,'-') P7615,\n" +
            "       nvl(e.mingcheng,'-') P7616,\n" +
            "       nvl(ckz.xmckz,'-') P7617,\n" +
            "       nvl(ckz.ckzdw,'-') P7618,\n" +
            "       case\n" +
            "         when IsNumeric(mx.jcjieguo) < 1 then\n" +
            "          '-'\n" +
            "         else\n" +
            "          nvl(mx.jcjieguo,'-')\n" +
            "       end P7620,\n" +
            "       case\n" +
            "         when IsNumeric(mx.jcjieguo) > 0 then\n" +
            "          '-'\n" +
            "         else\n" +
            "          nvl(mx.jcjieguo,'-')\n" +
            "       end P7621,\n" +
            "       nvl(d.tiaoxingma,'-') P7622,\n" +
            "       nvl(e.xiangmuid,'-') P7623,\n" +
            "       nvl(e.mingcheng,'-') P7624,\n" +
            "       decode(GetJGZ_Gxgg(mx.JCJIEGUO, e.XIAXIAN, e.SHANGXIAN),\n" +
            "              'H',\n" +
            "              '21',\n" +
            "              'L',\n" +
            "              '22',\n" +
            "              '1') P7625\n" +
            "  from m_lcfujian${param.year}     a,\n" +
            "       l_hisjcsqd         b,\n" +
            "       l_lisjcsqd         c,\n" +
            "       l_jianyanshuju     d，l_jianyanshuju_mx mx,\n" +
            "       l_xjcxiangmu       e,\n" +
            "       l_jianyanshuju_ckz ckz,\n" +
            "       m_dangan           da,\n" +
            "       l_x_biaoben        bb,\n" +
            "       x_fujianxiangmu    x,\n" +
            "       z_dangan_lgsb      lgsb\n" +
            " where a.fujianid = b.hissqid\n" +
            "   and b.hissqid = c.hissqid\n" +
            "   and c.lissqid = d.lissqid\n" +
            "   and d.jysjid = mx.jysjid\n" +
            "   and mx.xiangmuid = e.xiangmuid\n" +
            "   and mx.mxid = ckz.mxid\n" +
            "   and a.danganid = da.m_danganid\n" +
            "   and d.biaoben = bb.bbid\n" +
            "   and a.xiangmuid = x.xiangmuid\n" +
            "   and a.m_rizhiid = lgsb.m_rizhiid;\n";
    @Select(mLab)
    List<Lab> mLab(@Param("param")QueryParam param);

}
