package io.renren.modules.business.service.serviceImpl;

import com.alibaba.excel.EasyExcelFactory;
import com.google.common.base.Strings;
import io.renren.modules.business.DTO.QueryParam;
import io.renren.modules.business.dao.ReportsMapper;
import io.renren.modules.business.entity.HVConsumables;
import io.renren.modules.business.entity.outpatientDepartment.Drug;
import io.renren.modules.business.entity.outpatientDepartment.Examine;
import io.renren.modules.business.entity.outpatientDepartment.Fever;
import io.renren.modules.business.entity.outpatientDepartment.Lab;
import io.renren.modules.business.service.OutDeptDataService;
import io.renren.modules.business.util.DownloadUtil;
import net.lingala.zip4j.ZipFile;
import net.lingala.zip4j.exception.ZipException;
import net.lingala.zip4j.model.ZipParameters;
import net.lingala.zip4j.model.enums.AesKeyStrength;
import net.lingala.zip4j.model.enums.CompressionLevel;
import net.lingala.zip4j.model.enums.CompressionMethod;
import net.lingala.zip4j.model.enums.EncryptionMethod;
import org.joda.time.DateTime;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Async;
import org.springframework.scheduling.annotation.AsyncResult;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;
import org.springframework.util.ResourceUtils;

import javax.servlet.http.HttpServletResponse;
import java.io.*;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.concurrent.Future;

@Service("outDeptDataServiceImpl")
public class OutDeptDataServiceImpl implements OutDeptDataService {
    @Autowired
    private ReportsMapper reportsMapper;

    private static String DATE_PATTEN="yyyy-MM-dd HH:mm:ss";
    private static String DATE_PATTEN_YMD="yyyy-MM-dd";
//    private static String FILE_PATH="D:/temp/";
    private static String FILE_PATH;

    static {
        try {
            FILE_PATH = ResourceUtils.getURL("classpath:").getPath() + "temp/";
            File tempPath =new File(FILE_PATH);
            if (!tempPath.exists()){
                tempPath.mkdir();
            }
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    @Override
    public void outDeptData(HttpServletResponse response, QueryParam param){
        String startYMD = null;
        String endYMD = null;
        if (param.getStartDate()==null){
            startYMD = this.dayAddAndSub(Calendar.DATE,-1,DATE_PATTEN_YMD);
            param.setStartDate(startYMD);
        }

        if (param.getEndDate()==null){
            endYMD = this.dayAddAndSub(Calendar.DATE,-7,DATE_PATTEN_YMD);
            param.setEndDate(endYMD);
        }

        long startYear = Long.parseLong(startYMD.substring(0,4));
        long endYear = Long.parseLong(endYMD.substring(0,4));
        List<Drug> drugs = null;
        List<Examine> examines = null;
        List<Fever> fevers = null;
        List<Lab> labs = null;

        if (startYear<endYear){
            //查询数据跨年
            param.setEndDate(startYear+"-12-31");
            this.getData(param,drugs,examines,fevers,labs);

            List<Drug> drugs1 = null;
            List<Examine> examines1 = null;
            List<Fever> fevers1 = null;
            List<Lab> labs1 = null;
            param.setStartDate(startYear+"-01-01");
            param.setEndDate(endYMD);
            this.getData(param,drugs1,examines1,fevers1,labs1);
            drugs.addAll(drugs1);
            examines.addAll(examines1);
            fevers.addAll(fevers1);
            labs.addAll(labs1);
        }else {
            this.getData(param,drugs,examines,fevers,labs);
        }

        String fileName1 = FILE_PATH+"drug_诊疗处方记录表.xls";
        String fileName2 = FILE_PATH+"examine_辅助检查记录表.xls";
        String fileName3 = FILE_PATH+"fever_发热门诊病例信息.xls";
        String fileName4 = FILE_PATH+"lab_实验室检验详细记录表.xls";
        EasyExcelFactory.write(fileName1,Drug.class).sheet("drug_诊疗处方记录表").doWrite(drugs);
        EasyExcelFactory.write(fileName2,Examine.class).sheet("examine_辅助检查记录表").doWrite(examines);
        EasyExcelFactory.write(fileName3,Fever.class).sheet("fever_发热门诊病例信息").doWrite(fevers);
        EasyExcelFactory.write(fileName4,Lab.class).sheet("lab_实验室检验详细记录表").doWrite(labs);

        /**打包*/
        String zipName = zip();
        try {
            File zipFile =new File(OutDeptDataServiceImpl.FILE_PATH+zipName);
            BufferedInputStream zipIn = null;
            if (zipFile.exists()){
                zipIn =new BufferedInputStream(new FileInputStream(zipFile));
            }

            DownloadUtil.download(response,zipName,zipIn);
        } catch (IOException e) {
            e.printStackTrace();
        }

        /**删除tem文件*/
        File tepFile =new File(FILE_PATH);
        if (tepFile.exists()){
            File[] files = tepFile.listFiles();
            int length = files.length;
            for (int i = 0;i<length;i++){
                files[i].delete();
            }
        }
    }

    /**
     * 多线程获取数据
     */
    public void getData(QueryParam param, List<Drug> drugs,List<Examine> examines,List<Fever> fevers,List<Lab> labs){
        try {
            Future<String> result1 = this.getMDrug(drugs, param);
            Future<String> result2 = this.getMFever(fevers, param);
            Future<String> result3 = this.getMLab(labs, param);
            Future<String> result4 = this.getMExamines(examines, param);
            boolean back = false;
            while (!back){
                Thread.sleep(10000);
                if (result1.isDone() && result2.isDone() && result3.isDone() && result4.isDone()) {
                    back = true;
                    break;
                }
            }
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }

    public static String zip(){
        String zipName = String.format("发热门诊数据%s.rar", new DateTime().toString("yyyy-MM-dd"));
        // 生成的压缩文件
        ZipFile zipFile = new ZipFile(FILE_PATH+zipName);
        ZipParameters parameters = new ZipParameters();
        // 压缩方式
        parameters.setCompressionMethod(CompressionMethod.DEFLATE);
        // 压缩级别
        parameters.setCompressionLevel(CompressionLevel.NORMAL);
        // 是否设置加密文件
        parameters.setEncryptFiles(true);
        // 设置加密算法
        parameters.setEncryptionMethod(EncryptionMethod.AES);
        // 设置AES加密密钥的密钥强度
        parameters.setAesKeyStrength(AesKeyStrength.KEY_STRENGTH_256);
        // 设置密码
//        if(!Strings.isNullOrEmpty(password)) {
            zipFile.setPassword("3999".toCharArray());
//        }

        // 要打包的文件夹
        File file =new File(FILE_PATH);
        File[] fs = file.listFiles();

        // 遍历test文件夹下所有的文件、文件夹
        try {
            for (File f : fs) {
                if (f.isDirectory()) {
                    zipFile.addFolder(f, parameters);
                } else {
                    zipFile.addFile(f, parameters);
                }
            }
        } catch (ZipException e) {
            e.printStackTrace();
        }
        return zipName;
    }

    public static void main(String[] args) {
        OutDeptDataServiceImpl.zip();
    }

    /**
     * 日期加减
     * @param currentDay
     * @param day
     * @param patten
     * @return
     */
    public String dayAddAndSub(int currentDay, int day,String patten) {
        SimpleDateFormat sdf = null;
        if (patten==null){
            sdf = new SimpleDateFormat(DATE_PATTEN);
        }else {
            sdf = new SimpleDateFormat(patten);
        }
        Calendar calendar = Calendar.getInstance();
        calendar.add(currentDay, day);
        Date startDate = calendar.getTime();
        return sdf.format(startDate);
    }
//    public static void main(String[] args) {
//        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
//        Date currnetDate = new Date();
//        Calendar calendar = Calendar.getInstance();
//        //Date dateResult = test.dayAddAndSub(Calendar.HOUR , -4); //小时
//        //Date dateResult = test.dayAddAndSub(Calendar.MINUTE , -60); //分钟
//        //Date dateResult = test.dayAddAndSub(Calendar.MONTH , -1); //月
//        System.out.println(OutDeptDataServiceImpl.dayAddAndSub(Calendar.DATE , -19,null));
//    }

    @Async
    public Future<String> getMDrug(List<Drug> mDrug, QueryParam param) throws InterruptedException {
        String msg = "500";
        mDrug = reportsMapper.mDrug(param);
        return new AsyncResult<String>(msg);
    }

    @Async
    public Future<String> getMExamines(List<Examine> mExamines, QueryParam param) throws InterruptedException {
        String msg = "500";
        mExamines = reportsMapper.mExamine(param);
        return new AsyncResult<String>(msg);
    }

    @Async
    public Future<String> getMFever(List<Fever> mFever, QueryParam param) throws InterruptedException {
        String msg = "500";
        mFever = reportsMapper.mFever(param);
        return new AsyncResult<String>(msg);
    }

    @Async
    public Future<String> getMLab(List<Lab> mLab, QueryParam param) throws InterruptedException {
        String msg = "500";
        mLab = reportsMapper.mLab(param);
        return new AsyncResult<String>(msg);
    }
}
