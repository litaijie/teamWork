package io.renren.modules.business.service;

public interface ReportsService {
}
