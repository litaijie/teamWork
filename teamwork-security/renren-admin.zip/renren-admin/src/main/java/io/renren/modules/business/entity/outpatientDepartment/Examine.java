package io.renren.modules.business.entity.outpatientDepartment;

import com.alibaba.excel.annotation.ExcelProperty;
import lombok.Data;

/**
 *  examine_辅助检查记录表
 */
@Data
public class Examine {
    @ExcelProperty(value = "P7502",index = 0)
    private String P7502;
    @ExcelProperty(value = "P7506",index = 1)
    private String P7506;
    @ExcelProperty(value = "P7000",index = 2)
    private String P7000;
    @ExcelProperty(value = "P4",index =    3)
    private String P4;
    @ExcelProperty(value = "P7701",index = 4)
    private String P7701;
    @ExcelProperty(value = "P7702",index = 5)
    private String P7702;
    @ExcelProperty(value = "P7703",index = 6)
    private String P7703;
    @ExcelProperty(value = "P7704",index = 7)
    private String P7704;
    @ExcelProperty(value = "P7705",index = 8)
    private String P7705;
    @ExcelProperty(value = "P7706",index = 9)
    private String P7706;
    @ExcelProperty(value = "P7707",index = 10)
    private String P7707;
    @ExcelProperty(value = "P7708",index = 11)
    private String P7708;
    @ExcelProperty(value = "P7709",index = 12)
    private String P7709;
    @ExcelProperty(value = "P7710",index = 13)
    private String P7710;
    @ExcelProperty(value = "P7711",index = 14)
    private String P7711;
    @ExcelProperty(value = "P7712",index = 15)
    private String P7712;
    @ExcelProperty(value = "P7713",index = 16)
    private String P7713;
    @ExcelProperty(value = "P7714",index = 17)
    private String P7714;
    @ExcelProperty(value = "P7715",index = 18)
    private String P7715;
    @ExcelProperty(value = "P7716",index = 19)
    private String P7716;
    @ExcelProperty(value = "P7717",index = 20)
    private String P7717;
}
