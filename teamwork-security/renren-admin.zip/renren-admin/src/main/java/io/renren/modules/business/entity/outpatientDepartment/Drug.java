package io.renren.modules.business.entity.outpatientDepartment;

import com.alibaba.excel.annotation.ExcelProperty;
import lombok.Data;

/**
 * drug_诊疗处方记录表
 */
@Data
public class Drug {
    @ExcelProperty(value = "P7502",index = 0)
    private String P7502;
    @ExcelProperty(value = "P7506",index = 1)
    private String P7506;
    @ExcelProperty(value = "P7000",index = 2)
    private String P7000;
    @ExcelProperty(value = "P4",   index = 3)
    private String P4;
    @ExcelProperty(value = "P7800",index = 4)
    private String P7800;
    @ExcelProperty(value = "P7801",index = 5)
    private String P7801;
    @ExcelProperty(value = "P7802",index = 6)
    private String P7802;
    @ExcelProperty(value = "P7803",index = 7)
    private String P7803;
    @ExcelProperty(value = "P7804",index = 8)
    private String P7804;
    @ExcelProperty(value = "P7805",index = 9)
    private String P7805;
    @ExcelProperty(value = "P7806",index = 10)
    private String P7806;
    @ExcelProperty(value = "P7807",index = 11)
    private String P7807;
    @ExcelProperty(value = "P7808",index = 12)
    private String P7808;
    @ExcelProperty(value = "P7502",index = 13)
    private String P7810;
    @ExcelProperty(value = "P7810",index = 14)
    private String P7811;
    @ExcelProperty(value = "P7812",index = 15)
    private String P7812;
    @ExcelProperty(value = "P7813",index = 16)
    private String P7813;
    @ExcelProperty(value = "P7814",index = 17)
    private String P7814;
    @ExcelProperty(value = "P7815",index = 18)
    private String P7815;
    @ExcelProperty(value = "P7816",index = 19)
    private String P7816;
    @ExcelProperty(value = "P7817",index = 20)
    private String P7817;
    @ExcelProperty(value = "P7818",index = 21)
    private String P7818;
    @ExcelProperty(value = "P7819",index = 22)
    private String P7819;
    @ExcelProperty(value = "P7820",index = 23)
    private String P7820;
    @ExcelProperty(value = "P7821",index = 24)
    private String P7821;
    @ExcelProperty(value = "P7822",index = 25)
    private String P7822;
    @ExcelProperty(value = "P7823",index = 26)
    private String P7823;
    @ExcelProperty(value = "P7824",index = 27)
    private String P7824;
    @ExcelProperty(value = "P7825",index = 28)
    private String P7825;
    @ExcelProperty(value = "P7826",index = 29)
    private String P7826;
    @ExcelProperty(value = "P7827",index = 30)
    private String P7827;
    @ExcelProperty(value = "P7828",index = 31)
    private String P7828;
    @ExcelProperty(value = "P7829",index = 32)
    private String P7829;
    @ExcelProperty(value = "P7830",index = 33)
    private String P7830;
    @ExcelProperty(value = "P7831",index = 34)
    private String P7831;
    @ExcelProperty(value = "P7832",index = 35)
    private String P7832;
}
