package io.renren.modules.business.entity.outpatientDepartment;

import com.alibaba.excel.annotation.ExcelProperty;
import lombok.Data;

/**
 * lab_实验室检验详细记录表
 */
@Data
public class Lab {
    @ExcelProperty(value = "P7502",index = 0)
    private String P7502;
    @ExcelProperty(value = "P7506",index = 1)
    private String P7506;
    @ExcelProperty(value = "P7000",index = 2)
    private String P7000;
    @ExcelProperty(value = "P4",index =    3)
    private String P4;
    @ExcelProperty(value = "P7601",index = 4)
    private String P7601;
    @ExcelProperty(value = "P7602",index = 5)
    private String P7602;
    @ExcelProperty(value = "P7603",index = 6)
    private String P7603;
    @ExcelProperty(value = "P7604",index = 7)
    private String P7604;
    @ExcelProperty(value = "P7605",index = 8)
    private String P7605;
    @ExcelProperty(value = "P7606",index = 9)
    private String P7606;
    @ExcelProperty(value = "P7607",index = 10)
    private String P7607;
    @ExcelProperty(value = "P7608",index = 11)
    private String P7608;
    @ExcelProperty(value = "P7609",index = 12)
    private String P7609;
    @ExcelProperty(value = "P7610",index = 13)
    private String P7610;
    @ExcelProperty(value = "P7611",index = 14)
    private String P7611;
    @ExcelProperty(value = "P7612",index = 15)
    private String P7612;
    @ExcelProperty(value = "P7613",index = 16)
    private String P7613;
    @ExcelProperty(value = "P7614",index = 17)
    private String P7614;
    @ExcelProperty(value = "P7615",index = 18)
    private String P7615;
    @ExcelProperty(value = "P7616",index = 19)
    private String P7616;
    @ExcelProperty(value = "P7617",index = 20)
    private String P7617;
    @ExcelProperty(value = "P7618",index = 21)
    private String P7618;
    @ExcelProperty(value = "P7620",index = 22)
    private String P7620;
    @ExcelProperty(value = "P7621",index = 23)
    private String P7621;
    @ExcelProperty(value = "P7622",index = 24)
    private String P7622;
    @ExcelProperty(value = "P7623",index = 25)
    private String P7623;
    @ExcelProperty(value = "P7624",index = 26)
    private String P7624;
    @ExcelProperty(value = "P7625",index = 27)
    private String P7625;
}
