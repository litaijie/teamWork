package io.renren.modules.business.entity.outpatientDepartment;

import com.alibaba.excel.annotation.ExcelProperty;
import lombok.Data;

/**
 * fever_发热门诊病例信息
 */
@Data
public class Fever {
    @ExcelProperty(value = "P900",index =  0)
    private String P900;
    @ExcelProperty(value = "P6891",index = 1)
    private String P6891;
    @ExcelProperty(value = "P686",index =  2)
    private String P686;
    @ExcelProperty(value = "P800",index =  3)
    private String P800;
    @ExcelProperty(value = "P7501",index = 4)
    private String P7501;
    @ExcelProperty(value = "P7502",index = 5)
    private String P7502;
    @ExcelProperty(value = "P7000",index = 6)
    private String P7000;
    @ExcelProperty(value = "P4",index =    7)
    private String P4;
    @ExcelProperty(value = "P5",index =    8)
    private String P5;
    @ExcelProperty(value = "P6",index =    9)
    private String P6;
    @ExcelProperty(value = "P7",index =    10)
    private String P7;
    @ExcelProperty(value = "P12",index =   11)
    private String P12;
    @ExcelProperty(value = "P11",index =   12)
    private String P11;
    @ExcelProperty(value = "P8",index =    13)
    private String P8;
    @ExcelProperty(value = "P9",index =    14)
    private String P9;
    @ExcelProperty(value = "P7503",index = 15)
    private String P7503;
    @ExcelProperty(value = "P13",index =   16)
    private String P13;
    @ExcelProperty(value = "P801",index =  17)
    private String P801;
    @ExcelProperty(value = "P802",index =  18)
    private String P802;
    @ExcelProperty(value = "P803",index =  19)
    private String P803;
    @ExcelProperty(value = "P14",index =   20)
    private String P14;
    @ExcelProperty(value = "P15",index =   21)
    private String P15;
    @ExcelProperty(value = "P16",index =   22)
    private String P16;
    @ExcelProperty(value = "P17",index =   23)
    private String P17;
    @ExcelProperty(value = "P18",index =   24)
    private String P18;
    @ExcelProperty(value = "P19",index =   25)
    private String P19;
    @ExcelProperty(value = "P20",index =   26)
    private String P20;
    @ExcelProperty(value = "P21",index =   27)
    private String P21;
    @ExcelProperty(value = "P7505",index = 28)
    private String P7505;
    @ExcelProperty(value = "P7520",index = 29)
    private String P7520;
    @ExcelProperty(value = "P7521",index = 30)
    private String P7521;
    @ExcelProperty(value = "P7504",index = 31)
    private String P7504;
    @ExcelProperty(value = "P7522",index = 32)
    private String P7522;
    @ExcelProperty(value = "P7506",index = 33)
    private String P7506;
    @ExcelProperty(value = "P7507",index = 34)
    private String P7507;
    @ExcelProperty(value = "P7523",index = 35)
    private String P7523;
    @ExcelProperty(value = "P7524",index = 36)
    private String P7524;
    @ExcelProperty(value = "P7525",index = 37)
    private String P7525;
    @ExcelProperty(value = "P7526",index = 38)
    private String P7526;
    @ExcelProperty(value = "P7527",index = 39)
    private String P7527;
    @ExcelProperty(value = "P7528",index = 40)
    private String P7528;
    @ExcelProperty(value = "P7529",index = 41)
    private String P7529;
    @ExcelProperty(value = "P28",index =   42)
    private String P28;
    @ExcelProperty(value = "P281",index =  43)
    private String P281;
    @ExcelProperty(value = "P7530",index = 44)
    private String P7530;
    @ExcelProperty(value = "P1",index =    45)
    private String P1;
    @ExcelProperty(value = "P7508",index = 46)
    private String P7508;
    @ExcelProperty(value = "P7509",index = 47)
    private String P7509;
    @ExcelProperty(value = "P7510",index = 48)
    private String P7510;
    @ExcelProperty(value = "P7511",index = 49)
    private String P7511;
    @ExcelProperty(value = "P7512",index = 50)
    private String P7512;
}
