package io.renren.modules.business.entity;

public class DrugsByDept {
}
