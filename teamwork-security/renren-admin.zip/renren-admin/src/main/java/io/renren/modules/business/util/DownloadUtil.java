package io.renren.modules.business.util;

import com.alibaba.excel.EasyExcel;
import com.alibaba.excel.ExcelWriter;
import io.renren.modules.business.service.serviceImpl.OutDeptDataServiceImpl;

import javax.servlet.http.HttpServletResponse;
import java.io.BufferedInputStream;
import java.io.File;
import java.io.IOException;
import java.io.OutputStream;
import java.net.URLEncoder;
import java.text.SimpleDateFormat;
import java.util.Date;

public class DownloadUtil {

    public static void download(HttpServletResponse response, String fileName, BufferedInputStream fileIn) {
        OutputStream outputStream = null;
        try {
            outputStream = response.getOutputStream();

            //添加响应头信息
            response.setHeader("Content-disposition", "attachment; filename=" + URLEncoder.encode(fileName, "UTF-8"));
            //设置类型
            response.setContentType("application/octet-stream;charset=UTF-8");
            //设置头
            response.setHeader("Pragma", "No-cache");
            //设置头
            response.setHeader("Cache-Control", "no-cache");
            //设置日期头
            response.setDateHeader("Expires", 0);
            byte[] buffer = new byte[1024];
            int i = fileIn.read(buffer);
            while (i != -1) {
                outputStream.write(buffer, 0, i);
                i = fileIn.read(buffer);
            }

            outputStream.flush();
//            response.getOutputStream().close();
        } catch (IOException e) {
            e.printStackTrace();
        }finally {
            try {
                outputStream.close();
                fileIn.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }
}
