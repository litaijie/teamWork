var vm = new Vue({
    el:'#rrapp',
    data: {
        param: {
            year:null,
            yearMonth:null
        }
    },
    methods: {
        downloadOutDeptData: function () {
            var url = "business/outDeptDat/downloadOutDeptData";
            var xhr = new XMLHttpRequest();
            xhr.open('GET', baseURL+url, true);//get请求，请求地址，是否异步
            xhr.responseType = "blob";    // 返回类型blob

            xhr.addEventListener("progress", function (evt) {
                if (evt.lengthComputable) {
                    var percentComplete = evt.loaded / evt.total;
                    console.log(percentComplete);
                    $("#progressing").html((percentComplete * 100) + "%");
                }
            }, false);

            xhr.onload = function () {// 请求完成处理函数
                if (this.status === 200) {
                    var blob = this.response;// 获取返回值
                    var headerfileName =  this.getResponseHeader("Content-Disposition") ;
                    if(headerfileName){
                        fileName = decodeURI( headerfileName.replace('attachment; filename=','') );
                    }
                    var a = document.createElement('a');
                    a.download = fileName;
                    a.href=window.URL.createObjectURL(blob);
                    a.click();
                }
            };
            // 发送ajax请求
            xhr.send();
        }
    }
});